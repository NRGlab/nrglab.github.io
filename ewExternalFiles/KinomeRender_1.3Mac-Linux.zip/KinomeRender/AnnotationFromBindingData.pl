#!/usr/bin/perl -w

my @colors=("red", "blue", "green", "yellow", "magenta", "cyan", "orange", "pink", "grey");
my %atypical=("ADCK1",1,"ADCK2",1,"ADCK3",1,"ADCK4",1,"ADCK5",1,"ChaK1",1,"ChaK2",1,"AlphaK3",1,"EEF2K",1,"AlphaK2",1,"AlphaK1",1,"Brd2",1,"Brd3",1,"Brd4",1,"BrdT",1,"PDHK2",1,"PDHK3",1,"PDHK1",1,"PDHK4",1,"BCKDK",1,"ATM",1,"ATR",1,"mTOR/FRAP",1,"DNAPK",1,"SMG1",1,"TRRAP",1,"RIOK3",1,"RIOK2",1,"RIOK1",1,"TIF[alpha]",1,"TIF1[beta]",1,"TIF1[gamma]",1);


my $inputfile="";
my $outputfile="";
my $IdType="Name";
my $threshold="";
my $number=6;
my $nm=0;
my $mesure="Kd";
my $other=0;
my $scale=1;

while(@ARGV){
    my$arg=shift @ARGV;
    if($arg eq "-i"){$inputfile=shift @ARGV;}
    if($arg eq "-o"){$outputfile=shift @ARGV;}
    if($arg eq "-t"){$threshold=shift @ARGV;}
    if($arg eq "-y"){$IdType=shift @ARGV;}
    if($arg eq "-n"){$number=shift @ARGV;}
    if($arg eq "-nm"){$nm=1;}
    if($arg eq "-ic"){$mesure="IC50";}
    if($arg eq "-p"){$other=1;}
    if($arg eq "-ip"){$mesure="inhibperc";}
    if($arg eq "-s"){$scale=shift @ARGV;}
}

if($inputfile eq ""){die "using the argument -i <inputfile> is necessary to use the program";}

if($scale == 0){
    $scale=1;
    print "scale was set to 0: reseted to 1 to function\n";
}

my %id=();
open ID, "TableS1.txt";
$line=<ID>;
while($line=<ID>){
    my@line=split(/\t/,$line);
    if($IdType eq "IPI"){
	@ipi=split(/, /,$line[6]);
	foreach(@ipi){
	    $id{$_}=$line[1];
	}
    }elsif($IdType eq "Uniprot"){
	$id{$line[3]}=$line[1];
    }elsif($IdType eq "Name"){
	$id{$line[1]}=$line[1];
    }else{die "$IdType is not a valid Id type"}
}
close ID;

if($threshold!~/^\d+$/ && $threshold ne ""){die "threshold must be a number";}
if($number!~/^\d+$/||$number>6||$number<1){die "number of inhibitors per figure must be a number between 1 and 6";}
if($number!=1){$other=0;}

open INPUT, "$inputfile" or die "cannot open input file $inputfile";
my@affinities=();
my@inhibitors=();

my @text=<INPUT>;
my @completeText=();
foreach(@text){
    $_=~s/\r/\n/g;
    my @newlines=split(/\n+/,$_);
    push(@completeText,@newlines);
}
close INPUT;

my$header=shift @completeText;
my@header=split(/\t/,$header);
my$n=0;
shift @header;
push(@inhibitors, @header);
my $flag=0;
foreach(@completeText){
    my@line=split(/\t/, $_);
    $ID=shift @line;
    if(!(exists$id{$ID})){die "$ID is not a good identifier of type $IdType";}
    $name=$id{$ID};
    if(exists $atypical{$name}){$flag=1;}
    for($i=0;$i<scalar @line;$i++){
	$affinity=$line[$i];
	if($affinity ne "-" && $affinity ne "NA"){
	    if($threshold ne ""){
		if($affinity > $threshold){
		    if($other == 1){
			$n=int($i/$number);
			push(@{$affinities[$n]{0}},$name);
		    }
		    next;
		}
	    }
	    $n=int($i/$number);
	    $m=($i % $number);
	    $color=$colors[$m];
	    push(@{$affinities[$n]{$affinity}},$name.";".$color);
	}else{
	    if($affinity eq "-"){
		if($other == 1){
		     $n=int($i/$number);
		     push(@{$affinities[$n]{0}},$name);
		}
	    }
	}
    }
}

my$v1=(250/(&log10(1)+2)*$scale);
my$v10=(250/(&log10(10)+2)*$scale);
my$v100=(250/(&log10(100)+2)*$scale);
my$v1000=(250/(&log10(1000)+2)*$scale);
my$v10000=(250/(&log10(10000)+2)*$scale);
my @files=();

my @inhibitorscopy=@inhibitors;
for($i=0;$i<scalar @affinities;$i++){
    my $list="";
    my $small="";
    for($j=0;$j<$number;$j++){
	if(scalar @inhibitorscopy != 0){
	    my $current=shift @inhibitorscopy;
	    $list.=$current."_";
	}else{last;}
    }
    $list=~s/_$//g;
    if($outputfile ne "" && $outputfile!~/\/$/){
		open OUT, ">".$outputfile."_".$list.".inp";
		push(@files,$outputfile."_".$list);
    }elsif($outputfile=~/\/$/){
		open OUT, ">".$outputfile.$list.".inp";
		push(@files,$outputfile.$list);
    }else{
		open OUT, ">".$list.".inp";
		push(@files,$list);
    }
    @sortedAffi=sort{$a<=>$b} keys %{$affinities[$i]};
    if($mesure ne "inhibperc"){
	foreach$affi(@sortedAffi){
	    foreach$entry(@{$affinities[$i]{$affi}}){
		if($affi==0){
		    $small.="at ".$entry."\nscale 15\ncolor grey\ncircle-lined\n\n";
		}else{
		    @data=split(/;/, $entry);
		    if($affi<0.05){$affi=0.05}#here is the lower limit
		    $size=(250/(&log10($affi)+2))*$scale;
		    print OUT "at $data[0]\nscale ".$size."\ncolor $data[1]\ncircle-lined\n\n"
		}
	    }
	}
	if($number != 1){
	    if($nm==1){
		print OUT "legend\ncolor 0 0 0\nnext-line\nscale 20\ntext $mesure= 10 [mu]M\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nscale $v10000\ncolor grey\ncircle-lined\ncolor 0 0 0\nnext-line\nscale 20\ntext $mesure= 1 [mu]M\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nscale $v1000\ncolor grey\ncircle-lined\ncolor 0 0 0\nnext-line\nscale 20\ntext $mesure= 100 nM\nspace\nspace\nspace\nscale $v100\ncolor grey\ncircle-lined\ncolor 0 0 0\nnext-line\nscale 20\ntext $mesure= 10 nM\nspace\nspace\nspace\nscale $v10\ncolor grey\ncircle-lined\ncolor 0 0 0\nnext-line\nscale 20\ntext $mesure= 1 nM\nspace\nscale $v1\ncolor grey\ncircle-lined\nscale 40\n";
	    }else{
		print OUT "legend\ncolor 0 0 0\nnext-line\nscale 20\ntext $mesure= 10 mM\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nscale $v10000\ncolor grey\ncircle-lined\ncolor 0 0 0\nnext-line\nscale 20\ntext $mesure= 1 mM\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nscale $v1000\ncolor grey\ncircle-lined\ncolor 0 0 0\nnext-line\nscale 20\ntext $mesure= 100 [mu]M\nspace\nspace\nspace\nscale $v100\ncolor grey\ncircle-lined\ncolor 0 0 0\nnext-line\nscale 20\ntext $mesure= 10 [mu]M\nspace\nspace\nspace\nscale $v10\ncolor grey\ncircle-lined\ncolor 0 0 0\nnext-line\nscale 20\ntext $mesure= 1 [mu]M\nspace\nscale $v1\ncolor grey\ncircle-lined\nscale 40\n";
	    }
	    for($j=0;$j<$number;$j++){
		if(scalar @inhibitors != 0){
		    my $current=shift @inhibitors; 
		    print OUT "next-line\ncolor 0 0 0\nscale 20\ntext ".$current."\nspace\ncolor ".$colors[$j]."\nscale 30\ncircle-lined\n";
		}else{last;}
	    }
	    close OUT;
	}else{
	    if($small ne ""){
		print OUT $small;
	    }
	    if($nm==1){
		print OUT "legend\ncolor 0 0 0\nnext-line\nscale 20\ntext $mesure= 10 [mu]M\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nscale $v10000\ncolor red\ncircle-lined\ncolor 0 0 0\nnext-line\nscale 20\ntext $mesure= 1 [mu]M\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nscale $v1000\ncolor red\ncircle-lined\ncolor 0 0 0\nnext-line\nscale 20\ntext $mesure= 100 nM\nspace\nspace\nspace\nscale $v100\ncolor red\ncircle-lined\ncolor 0 0 0\nnext-line\nscale 20\ntext $mesure= 10 nM\nspace\nspace\nspace\nscale $v10\ncolor red\ncircle-lined\ncolor 0 0 0\nnext-line\nscale 20\ntext $mesure= 1 nM\nspace\nscale $v1\ncolor red\ncircle-lined\n";
	    }else{
		print OUT "legend\ncolor 0 0 0\nnext-line\nscale 20\ntext $mesure= 10 mM\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nscale $v10000\ncolor red\ncircle-lined\ncolor 0 0 0\nnext-line\nscale 20\ntext $mesure= 1 mM\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nscale $v1000\ncolor red\ncircle-lined\ncolor 0 0 0\nnext-line\nscale 20\ntext $mesure= 100 [mu]M\nspace\nspace\nspace\nscale $v100\ncolor red\ncircle-lined\ncolor 0 0 0\nnext-line\nscale 20\ntext $mesure= 10 [mu]M\nspace\nspace\nspace\nscale $v10\ncolor red\ncircle-lined\ncolor 0 0 0\nnext-line\nscale 20\ntext $mesure= 1 [mu]M\nspace\nscale $v1\ncolor red\ncircle-lined\n";
	    }
	    close OUT;
	}
    }else{
	$negflag=0;
	foreach$affi(@sortedAffi){
	    foreach$entry(@{$affinities[$i]{$affi}}){
		@data=split(/;/, $entry);
		if($affi >=0){
		    $size=($affi+10)*$scale;
		    print OUT "at $data[0]\nscale ".$size."\ncolor $data[1]\ncircle-lined\n\n";
		}else{
		    $negflag=1;
		    $size=(abs($affi)+10)*$scale;
		    print OUT "at $data[0]\nscale ".$size."\ncolor $data[1]\npolygon-lined 3\n\n";
		}
	    }
	}
	if($number != 1){
	    print OUT "legend\ncolor 0 0 0\nnext-line\nscale 20\ntext 20% inhibition\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nscale ".(30*$scale)."\ncolor grey\ncircle-lined\ncolor 0 0 0\nscale ".(50*$scale)."\nnext-line\nscale 20\ntext 60% inhibition\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nscale ".(70*$scale)."\ncolor grey\ncircle-lined\ncolor 0 0 0\nscale ".(75*$scale)."\nnext-line\nscale 20\ntext 100% inhibition\nspace\nscale ".(110*$scale)."\ncolor grey\ncircle-lined\n";
	    if($negflag==1){
		print OUT "scale 35\nnext-line\ncolor 0 0 0\nscale 20\ntext positive inhibition %\nspace\ncolor grey\nscale 30\ncircle-lined\nnext-line\ncolor 0 0 0\nscale 20\ntext negative inhibition %\nspace\ncolor grey\nscale 30\npolygon-lined 3\n";
	    }
	    for($j=0;$j<$number;$j++){
		if(scalar @inhibitors != 0){
		    my $current=shift @inhibitors; 
		    print OUT "scale 35\nnext-line\ncolor 0 0 0\nscale 20\ntext ".$current."\nspace\ncolor ".$colors[$j]."\nscale 30\ncircle-lined\n";
		}else{last;}
	    }
	}else{
	    print OUT "legend\ncolor 0 0 0\nnext-line\nscale 20\ntext 20% inhibition\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nscale ".(30*$scale)."\ncolor red\ncircle-lined\ncolor 0 0 0\nscale ".(50*$scale)."\nnext-line\nscale 20\ntext 60% inhibition\nspace\nspace\nspace\nspace\nspace\nspace\nspace\nscale ".(70*$scale)."\ncolor red\ncircle-lined\ncolor 0 0 0\nscale ".(75*$scale)."\nnext-line\nscale 20\ntext 100% inhibition\nspace\nscale ".(110*$scale)."\ncolor red\ncircle-lined\n";	    
	    if($negflag==1){
		print OUT "scale 35\nnext-line\ncolor 0 0 0\nscale 20\ntext positive inhibition %\nspace\ncolor red\nscale 30\ncircle-lined\nnext-line\ncolor 0 0 0\nscale 20\ntext negative inhibition %\nspace\ncolor red\nscale 30\npolygon-lined 3\n";
	    }
	}
	close OUT;
    }
}
foreach $file (@files){
    if($flag==1){
	system("./kinome-render -i ".$file.".inp -o ".$file.".ps -t2");
    }else{
	system("./kinome-render -i ".$file.".inp -o ".$file.".ps");
    }
    print $file."\n";
}
print "#allOk\n";

sub log10{
    my $n = shift;
    return log($n)/log(10);
}
