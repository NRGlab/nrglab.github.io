# ==============================================================================
# Parser.pm
# Jonathan Barker, 2005
# ==============================================================================
# The parser parses and produces PostScript for each line of input.
# ==============================================================================

package Parser;
use strict;
use warnings;
use Encoder;
use Map;

# ==============================================================================
# class Parser
# ==============================================================================

sub new($)
{
    my $class=shift;
    my $map=new Map;
    my $encoder=new Encoder;

    return bless {'map'=>$map,'encoder'=>$encoder,'used'=>{}},$class;
}

sub parse($$$)
{
    my $self=shift;
    my $line=shift;
    my $name=shift;
    my $color=shift;
    my $N="([0-9]+(\.[0-9]+)?)";
    my $after="/kinomeX kinomeX kinomeScale 2 div add 3 add def /kinomeY kinomeY kinomeScale 3 div add def\n";
    my %predefined = (
        "black" => "0 0 0",
        "red" => "0.83 0.17 0",
        "green" => "0 0.67 0",
        "blue" => "0 0 1",
        "yellow" => "1 1 0",
        "magenta" => "1 0 1",
        "cyan" => "0 1 1",
        "orange" => "1 0.65 0",
        "pink" => "1 0.75 0.8",
        "grey" => "0.75 0.75 0.75",
    );

    if($line =~ /^at\s+([^\s]+)$/)
    {
        my $p=$1;
        my $loc = $self->{'map'}->locate($p);
        die "$p: no such protein/gene defined in map" unless defined $p;
        $self->{used}->{$p}=1;
        return (2,$p,"/kinomeX $loc->{x} def /kinomeY $loc->{y} def\n");
    }

    if($line =~ /^space$/)
    {
        return (1,"/kinomeX kinomeX kinomeScale 4 div add def\n");
    }

    if($line =~ /^text\s*(.*)$/)
    {
	my $word=$1;
	if($word eq ""){$word=$name;}
        my $e=$self->{'encoder'}->encode($word);
        return (1,"$e kinomeShow\n");
    }

    if($line=~/^scale\s+$N$/)
    {
        return (1,"/kinomeScale $1 def\n");
    }

    if($line=~/^colour\s+$N\s+$N\s+$N$/ || $line=~/^color\s+$N\s+$N\s+$N$/)
    {
        return (3,"$1 $3 $5","$1 $3 $5 setrgbcolor\n");
    }

    if($line=~/^color\s+(.*)$/|| $line=~/colour\s+(.*)$/)
    {
	if(!(exists $predefined{$1})){die "color \"".$1."\" is not a predefined color"};
	my $rgb=$predefined{$1};
	return (3,$rgb,$rgb." setrgbcolor\n");
    }
    if($line=~/^polygon\s+([0-9]+)$/)
    {	
	my $loc = $self->{'map'}->locate($name);
	my $try="kinomeX $loc->{x} sub kinomeY $loc->{y} sub add 0 eq\n";
	my $adjustment=&adjustment($name);
        return (1,$try."{".$adjustment."}\n{".$after."} ifelse\n$1 kinomeShowPoly\n");
    }

    if($line=~/^polygon-filled\s+([0-9]+)$/)
    {
	my $loc = $self->{'map'}->locate($name);
	my $try="kinomeX $loc->{x} sub kinomeY $loc->{y} sub add 0 eq\n";
	my $adjustment=&adjustment($name);
        return (1,$try."{".$adjustment."}\n{".$after."} ifelse\n$1 kinomeShowPolyFilled\n");
    }
 
    if($line=~/^polygon-lined\s+([0-9]+)$/)
    {
	my $loc = $self->{'map'}->locate($name);
	my $try="kinomeX $loc->{x} sub kinomeY $loc->{y} sub add 0 eq\n";
	my $adjustment=&adjustment($name);
        return (1,$try."{".$adjustment."}\n{".$after."} ifelse\n0 0 0 $1 kinomeShowPolyLined\n$color setrgbcolor\n");
    }

    if($line=~/^linewidth\s+($N)$/)
    {
        return (1,"$1 setlinewidth\n");
    }

    if($line=~/^circle$/)
    {
	my $loc = $self->{'map'}->locate($name);
	my $try="kinomeX $loc->{x} sub kinomeY $loc->{y} sub add 0 eq\n";
	my $adjustment=&adjustment($name);
        return (1,$try."{".$adjustment."}\n{".$after."} ifelse\nkinomeShowCircle\n");
    }

    if($line=~/^circle-filled$/)
    {
	my $loc = $self->{'map'}->locate($name);
	my $try="kinomeX $loc->{x} sub kinomeY $loc->{y} sub add 0 eq\n";
	my $adjustment=&adjustment($name);
        return (1,$try."{".$adjustment."}\n{".$after."} ifelse\nkinomeShowCircleFilled\n");
    }

    if($line=~/^circle-lined$/)
    {
	my $loc = $self->{'map'}->locate($name);
	my $try="kinomeX $loc->{x} sub kinomeY $loc->{y} sub add 0 eq\n";
	my $adjustment=&adjustment($name);
        return (1,$try."{".$adjustment."}\n{".$after."} ifelse\n0 0 0 kinomeShowCircleLined\n$color setrgbcolor\n");
    }

    if($line=~/^boxed$/)
    {
	my $left=1150;
	if($name ne "legend"){
	    my $loc = $self->{'map'}->locate($name);
	    $left = $loc->{x};
	}
	return (1,$left." kinomeBox\n");
    }

    if($line=~/^underlined$/){
	my $left=1150;
	if($name ne "legend"){
	    my $loc = $self->{'map'}->locate($name);
	    $left = $loc->{x};
	}
	return (1,$left." kinomeUnderlined\n");
    }

    if($line=~/^legend$/)
    {
	return (4,"kinomeLegend\n");
    }

    if($line=~/^legendBox$/)
    {
	return (1,"kinomeLegendBox\n$color setrgbcolor\n");
    }

    if($line=~/^next-line$/)
    {
	return (1,"kinomeNextLine\n");
    }

    if($line=~/^remainder$/)
    {
        my @result=("0 setgray\n/kinomeScale 10 def\n");
        
        return (5,@result);
    }

    die "syntax error";
}

# ==============================================================================
sub adjustment($){
    my $name=shift;
    if($name eq "MYT1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "Wee1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "Wee1B"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "PIK3R4"){
	return "";
    }elsif($name eq "SgK493"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "VRK1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "VRK2"){
	return "/kinomeX kinomeX 18 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "Bub1"){
	return "/kinomeX kinomeX 3 add def\n";
    }elsif($name eq "BubR1"){
	return "/kinomeX kinomeX 14 add def\n";
    }elsif($name eq "CK1[gamma]2"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "CK1[alpha]"){
	return "/kinomeX kinomeX 3 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "CK1[alpha]2"){
	return "/kinomeX kinomeX 3 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "CK1[delta]"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "CK1[epsilon]"){
	return "/kinomeX kinomeX 4 add def\n";
    }elsif($name eq "CK1[gamma]1"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "CK1[gamma]3"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "PRPK"){
	return "/kinomeX kinomeX 4 add def\n";
    }elsif($name eq "Haspin"){
	return "/kinomeX kinomeX 4 add def\n";
    }elsif($name eq "SCYL2"){
	return "/kinomeX kinomeX 24 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "SCYL3"){
	return "/kinomeX kinomeX 14 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "SCYL1"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "SgK196"){
	return "/kinomeX kinomeX 5 add def\n";
    }elsif($name eq "SgK396"){
	return "/kinomeX kinomeX 3 add def\n";
    }elsif($name eq "Slob"){
	return "";
    }elsif($name eq "VRK3"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "MSK1"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 7 add def\n";
    }elsif($name eq "p70S6K"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "p70S6K[beta]"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "RSK3"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "PKC[iota]"){
	return "/kinomeX kinomeX 2 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "PKC[zeta]"){
	return "/kinomeX kinomeX 2 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "PKN3"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "RSK4"){
	return "/kinomeX kinomeX 2 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "PKC[delta]"){
	return "/kinomeX kinomeX 2 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "PKC[theta]"){
	return "/kinomeX kinomeX 2 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "RSK1/p90RSK"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "RSK2"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "PKC[gamma]"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "PKC[eta]"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "PKC[epsilon]"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "PKC[alpha]"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "PKC[beta]"){
	return "/kinomeX kinomeX 2 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "GRK4"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "GRK5"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "TLK2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "PLK1"){
	return "/kinomeX kinomeX 12 add def\n";
    }elsif($name eq "PLK2"){
	return "";
    }elsif($name eq "PLK3"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "PLK4"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "MRCK[beta]"){
	return "/kinomeX kinomeX 3 add def /kinomeY kinomeY 0 add def\n";
    }elsif($name eq "MRCK[alpha]"){
	return "/kinomeX kinomeX 14 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "GRK6"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "RHODK/GRK1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "AurA/Aur2"){
	return "/kinomeX kinomeX 18 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "TLK1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "AurB/Aur1"){
	return "";
    }elsif($name eq "AurC/Aur3"){
	return "/kinomeX kinomeX 25 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "DMPK"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY -3 add def\n";
    }elsif($name eq "ROCK1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY -3 add def\n";
    }elsif($name eq "ROCK2"){
	return "";
    }elsif($name eq "NDR1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "NDR2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "DMPK2"){
	return "/kinomeX kinomeX 4 add def\n";
    }elsif($name eq "YANK2"){
	return "";
    }elsif($name eq "YANK3"){
	return "/kinomeX kinomeX 17 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "YANK1"){
	return "/kinomeX kinomeX 14 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "SgK494"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "PDK1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "BARK1/GRK2"){
	return "/kinomeX kinomeX 9 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "BARK2/GRK3"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "GRK7"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "MAST3"){
	return "/kinomeX kinomeX 5 add def\n";
    }elsif($name eq "MASTL"){
	return "/kinomeX kinomeX 18 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "MAST2"){
	return "/kinomeX kinomeX 30 add def\n";
    }elsif($name eq "MAST4"){
	return "/kinomeX kinomeX 25 add def\n";
    }elsif($name eq "MAST1"){
	return "";
    }elsif($name eq "PKN1/PRK1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "PKN2/PRK2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "MSK2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 0 add def\n";
    }elsif($name eq "LATS1"){
	return "/kinomeX kinomeX 2 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "LATS2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "Akt1/PKB[alpha]"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "Akt2/PKB[beta]"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "Akt3/PKB[gamma]"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "SGK1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "SGK2"){
	return "/kinomeX kinomeX 8 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "SGK3"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "CRIK"){
	return "/kinomeX kinomeX 12 add def\n";
    }elsif($name eq "PKG2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "PKG1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "PRKY"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "PKA[alpha]"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "PKA[beta]"){
	return "";
    }elsif($name eq "PRKX"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "PKA[gamma]"){
	return "/kinomeX kinomeX 15 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "CAMKK1"){
	return "/kinomeX kinomeX 31 add def /kinomeY kinomeY 8 add def\n";
    }elsif($name eq "CAMKK2"){
	return "/kinomeX kinomeX 36 add def\n";
    }elsif($name eq "ULK1"){
	return "/kinomeX kinomeX 20 add def\n";
    }elsif($name eq "ULK2"){
	return "/kinomeX kinomeX 21 add def\n";
    }elsif($name eq "BIKE"){
	return "/kinomeX kinomeX 20 add def\n";
    }elsif($name eq "AAK1"){
	return "/kinomeX kinomeX 20 add def\n";
    }elsif($name eq "SBK"){
	return "/kinomeX kinomeX 15 add def\n";
    }elsif($name eq "RSKL2"){
	return "/kinomeX kinomeX 5 add def\n";
    }elsif($name eq "RSKL1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "IKK[alpha]"){
	return "/kinomeX kinomeX 17 add def\n";
    }elsif($name eq "IKK[beta]"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY -2 add def\n";
    }elsif($name eq "TBK1"){
	return "/kinomeX kinomeX 18 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "SgK110"){
	return "/kinomeX kinomeX 37 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "SgK069"){
	return "/kinomeX kinomeX 35 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "IKK[epsilon]"){
	return "/kinomeX kinomeX 18 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "GAK"){
	return "/kinomeX kinomeX 15 add def\n";
    }elsif($name eq "MPSK1"){
	return "/kinomeX kinomeX 27 add def\n";
    }elsif($name eq "MAP2K5"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "MAP2K7"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "OSR1"){
	return "/kinomeX kinomeX 15 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "STLK3"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "STLK5"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "STLK6"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "MKK3/MAP2K3"){
	return "/kinomeX kinomeX 5 add def\n";
    }elsif($name eq "MKK6/MAP2K6"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "SEK1/MAP2K4"){
	return "/kinomeX kinomeX 55 add def\n";
    }elsif($name eq "PAK6"){
	return "/kinomeX kinomeX 5 add def\n";
    }elsif($name eq "PAK3"){
	return "";
    }elsif($name eq "TAO3"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "MEK2/MAP2K2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "MEK1/MAP2K1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "SLK"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "LOK"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "COT"){
	return "/kinomeX kinomeX 6 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "NIK"){
	return "/kinomeX kinomeX 8 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "GCN2~b"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "TAO1"){
	return "/kinomeX kinomeX 5 add def\n";
    }elsif($name eq "TAO2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "PAK1"){
	return "/kinomeX kinomeX 5 add def\n";
    }elsif($name eq "PAK2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "PAK4"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "PAK5"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "PBK"){
	return "/kinomeX kinomeX 15 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "CDK11"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "CDK8"){
	return "/kinomeX kinomeX 24 add def\n";
    }elsif($name eq "ERK7"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "ERK3"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "ERK4"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "CDKL5"){
	return "/kinomeX kinomeX 30 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "GSK3[alpha]"){
	return "/kinomeX kinomeX 30 add def /kinomeY kinomeY 7 add def\n";
    }elsif($name eq "GSK3[beta]"){
	return "/kinomeX kinomeX 28 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "ICK"){
	return "/kinomeX kinomeX 12 add def\n";
    }elsif($name eq "MAK"){
	return "/kinomeX kinomeX 14 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "CCRK"){
	return "/kinomeX kinomeX 15 add def\n";
    }elsif($name eq "CDK9"){
	return "/kinomeX kinomeX 15 add def\n";
    }elsif($name eq "CDK7"){
	return "/kinomeX kinomeX 13 add def /kinomeY kinomeY -4 add def\n";
    }elsif($name eq "CDKL4"){
	return "/kinomeX kinomeX 25 add def\n";
    }elsif($name eq "CDKL1"){
	return "/kinomeX kinomeX 25 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "NLK"){
	return "/kinomeX kinomeX 12 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "CDKL3"){
	return "/kinomeX kinomeX 28 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "CDKL2"){
	return "/kinomeX kinomeX 28 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "CHED"){
	return "/kinomeY kinomeY 2 add def\n";
    }elsif($name eq "CRK7"){
	return "/kinomeX kinomeX 13 add def\n";
    }elsif($name eq "CDK6"){
	return "/kinomeX kinomeX 20 add def\n";
    }elsif($name eq "CDK10"){
	return "/kinomeX kinomeX 26 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "CDK4"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "PITSLRE"){
	return "/kinomeX kinomeX 22 add def /kinomeY kinomeY -4 add def\n";
    }elsif($name eq "ERK5"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "JNK2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "CDK5"){
	return "/kinomeX kinomeX 18 add def\n";
    }elsif($name eq "ERK1"){
	return "/kinomeX kinomeX 19 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "JNK1"){
	return "/kinomeX kinomeX 18 add def\n";
    }elsif($name eq "JNK3"){
	return "/kinomeX kinomeX 16 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "ERK2"){
	return "/kinomeX kinomeX 19 add def\n";
    }elsif($name eq "p38[alpha]"){
	return "/kinomeX kinomeX 18 add def\n";
    }elsif($name eq "p38[beta]"){
	return "/kinomeX kinomeX 20 add def\n";
    }elsif($name eq "p38[delta]"){
	return "/kinomeX kinomeX 17 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "p38[gamma]"){
	return "/kinomeX kinomeX 17 add def /kinomeY kinomeY 1 add def\n";
    }elsif($name eq "CDC2/CDK1"){
	return "/kinomeX kinomeX 14 add def\n";
    }elsif($name eq "PCTAIRE3"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "PFTAIRE1"){
	return "/kinomeX kinomeX 45 add def\n";
    }elsif($name eq "PCTAIRE1"){
	return "/kinomeX kinomeX 45 add def\n";
    }elsif($name eq "PCTAIRE2"){
	return "/kinomeX kinomeX 45 add def\n";
    }elsif($name eq "PFTAIRE2"){
	return "/kinomeX kinomeX 45 add def\n";
    }elsif($name eq "CDK2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "CDK3"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "MOK"){
	return "/kinomeX kinomeX 5 add def\n";
    }elsif($name eq "CK2[alpha]1"){
	return "/kinomeX kinomeX 22 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "CK2[alpha]2"){
	return "/kinomeX kinomeX 22 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "SgK071"){
	return "/kinomeX kinomeX 28 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "RNAseL"){
	return "/kinomeX kinomeX 33 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "CLIK1L"){
	return "/kinomeX kinomeX 22 add def\n";
    }elsif($name eq "CLIK1"){
	return "/kinomeX kinomeX 15 add def\n";
    }elsif($name eq "TTK"){
	return "/kinomeX kinomeX 13 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "KIS"){
	return "/kinomeX kinomeX 13 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "IRE1"){
	return "/kinomeX kinomeX 20 add def\n";
    }elsif($name eq "IRE2"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "TBCK"){
	return "/kinomeX kinomeX 4 add def\n";
    }elsif($name eq "HRI"){
	return "/kinomeX kinomeX 4 add def\n";
    }elsif($name eq "GCN2"){
	return "/kinomeX kinomeX 9 add def\n";
    }elsif($name eq "PKR"){
	return "/kinomeX kinomeX 14 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "PERK/PEK"){
	return "/kinomeX kinomeX 20 add def\n";
    }elsif($name eq "CDC7"){
	return "/kinomeX kinomeX 13 add def /kinomeY kinomeY -3 add def\n";
    }elsif($name eq "MAP3K4"){
	return "/kinomeX kinomeX 27 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "KHS1"){
	return "/kinomeX kinomeX 15 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "KHS2"){
	return "/kinomeX kinomeX 7 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "NRK/ZC4"){
	return "/kinomeX kinomeX 19 add def /kinomeY kinomeY 8 add def\n";
    }elsif($name eq "MYO3A"){
	return "/kinomeX kinomeX 7 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "MYO3B"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "MST1"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY -5 add def\n";
    }elsif($name eq "MST2"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY -5 add def\n";
    }elsif($name eq "MAP3K8"){
	return "/kinomeX kinomeX 25 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "MST4"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "TNIK/ZC2"){
	return "/kinomeX kinomeX 7 add def /kinomeY kinomeY 7 add def\n";
    }elsif($name eq "MINK/ZC3"){
	return "/kinomeX kinomeX 3 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "HGK/ZC1"){
	return "/kinomeX kinomeX 3 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "MEKK6/MAP3K6"){
	return "/kinomeX kinomeX 18 add def /kinomeY kinomeY 10 add def\n";
    }elsif($name eq "RIPK3"){
	return "/kinomeX kinomeX 15 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "LIMK1"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY -5 add def\n";
    }elsif($name eq "LIMK2"){
	return "/kinomeX kinomeX 15 add def /kinomeY kinomeY -2 add def\n";
    }elsif($name eq "TESK1"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "TESK2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 13 add def\n";
    }elsif($name eq "ALK1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "ALK2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "MISR2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "TGF[beta]R2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "BMPR2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "RIPK2"){
	return "/kinomeX kinomeX 17 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "HH498"){
	return "/kinomeX kinomeX 6 add def /kinomeY kinomeY 10 add def\n";
    }elsif($name eq "TAK1"){
	return "/kinomeX kinomeX 8 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "ILK"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "BMPR1A"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "ARAF"){
	return "/kinomeX kinomeX 13 add def /kinomeY kinomeY -5 add def\n";
    }elsif($name eq "KSR"){
	return "/kinomeX kinomeX 15 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "KSR2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "BMPR1B"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "ALK7"){
	return "/kinomeX kinomeX 8 add def /kinomeY kinomeY -4 add def\n";
    }elsif($name eq "ANKRD3"){
	return "/kinomeX kinomeX 28 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "ACtR2"){
	return "/kinomeX kinomeX 3 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "ACtR2B"){
	return "/kinomeX kinomeX 3 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "SgK288"){
	return "/kinomeX kinomeX 3 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "ZAK"){
	return "/kinomeX kinomeX 5 add def\n";
    }elsif($name eq "BRAF"){
	return "/kinomeX kinomeX 8 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "RAF1"){
	return "/kinomeX kinomeX 13 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "ALK4"){
	return "/kinomeX kinomeX 7 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "TGF[beta]R1"){
	return "/kinomeX kinomeX 3 add def\n";
    }elsif($name eq "DLK"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "LZK"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "MLK3"){
	return "/kinomeX kinomeX 13 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "MLK1"){
	return "/kinomeX kinomeX 3 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "MLK2"){
	return "/kinomeX kinomeX 17 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "MLK4"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "SgK496"){
	return "/kinomeX kinomeX 18 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "RIPK1"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "LRRK2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY -5 add def\n";
    }elsif($name eq "LRRK1"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "WNK1"){
	return "/kinomeX kinomeX 3 add def /kinomeY kinomeY -2 add def\n";
    }elsif($name eq "WNK2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "WNK3"){
	return "/kinomeX kinomeX 3 add def\n";
    }elsif($name eq "WNK4"){
	return "/kinomeX kinomeX 11 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "NRBP1"){
	return "/kinomeX kinomeX 29 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "NRBP2"){
	return "/kinomeX kinomeX 6 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "MEKK1/MAP3K1"){
	return "/kinomeX kinomeX 29 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "MEKK2/MAP3K2"){
	return "/kinomeX kinomeX 8 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "MEKK3/MAP3K3"){
	return "/kinomeY kinomeY 6 add def\n";
    }elsif($name eq "ASK/MAP3K5"){
	return "/kinomeX kinomeX 3 add def /kinomeY kinomeY 8 add def\n";
    }elsif($name eq "MAP3K7"){
	return "/kinomeX kinomeX 6 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "MLKL"){
	return "/kinomeX kinomeX 9 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "SgK307"){
	return "/kinomeX kinomeX 25 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "SgK424"){
	return "/kinomeX kinomeX 35 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "HSER"){
	return "/kinomeX kinomeX 24 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "CYGD"){
	return "/kinomeX kinomeX 22 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "CYGF"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "ANP[alpha]"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "ANP[beta]"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "IRAK1"){
	return "/kinomeX kinomeX 9 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "IRAK2"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "IRAK3"){
	return "/kinomeX kinomeX 30 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "IRAK4"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "Fused"){
	return "/kinomeX kinomeX 23 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "ULK3"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "ULK4"){
	return "/kinomeX kinomeX 22 add def\n";
    }elsif($name eq "MELK"){
	return "/kinomeX kinomeX 13 add def\n";
    }elsif($name eq "NIM1"){
	return "/kinomeX kinomeX 15 add def /kinomeY kinomeY -2 add def\n";
    }elsif($name eq "SNRK"){
	return "/kinomeX kinomeX 17 add def /kinomeY kinomeY 10 add def\n";
    }elsif($name eq "SSTK"){
	return "/kinomeX kinomeX 18 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "TSSK3"){
	return "/kinomeX kinomeX 26 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "TSSK1"){
	return "/kinomeX kinomeX 26 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "AMPK[alpha]1"){
	return "/kinomeX kinomeX 38 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "AMPK[alpha]2"){
	return "/kinomeX kinomeX 38 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "BRSK1"){
	return "/kinomeX kinomeX 28 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "BRSK2"){
	return "/kinomeX kinomeX 29 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "NuaK1"){
	return "/kinomeX kinomeX 28 add def\n";
    }elsif($name eq "NuaK2"){
	return "/kinomeX kinomeX 28 add def\n";
    }elsif($name eq "QSK"){
	return "/kinomeX kinomeX 18 add def\n";
    }elsif($name eq "QIK"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "SIK"){
	return "/kinomeX kinomeX 12 add def /kinomeY kinomeY 7 add def\n";
    }elsif($name eq "MARK1"){
	return "/kinomeX kinomeX 26 add def /kinomeY kinomeY 8 add def\n";
    }elsif($name eq "MARK2"){
	return "/kinomeX kinomeX 18 add def\n";
    }elsif($name eq "MARK3"){
	return "/kinomeX kinomeX 8 add def\n";
    }elsif($name eq "MARK4"){
	return "/kinomeX kinomeX 10 add def\n";
    }elsif($name eq "RSK3~b"){
	return "/kinomeX kinomeX 6 add def\n";
    }elsif($name eq "CaMK1[beta]"){
	return "/kinomeX kinomeX 8 add def /kinomeY kinomeY 1 add def\n";
    }elsif($name eq "CaMK1[gamma]"){
	return "/kinomeX kinomeX 8 add def\n";
    }elsif($name eq "CHK2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "PKD2"){
	return "/kinomeX kinomeX 12 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "HUNK"){
	return "/kinomeX kinomeX 12 add def\n";
    }elsif($name eq "DCAMKL3"){
	return "/kinomeX kinomeX 33 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "CASK"){
	return "/kinomeX kinomeX 6 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "MAPKAPK5"){
	return "/kinomeX kinomeX 32 add def\n";
    }elsif($name eq "VACAMKL"){
	return "/kinomeX kinomeX 7 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "PSKH1"){
	return "/kinomeX kinomeX 2 add def /kinomeY kinomeY -2 add def\n";
    }elsif($name eq "PSKH2"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "MAPKAPK2"){
	return "/kinomeX kinomeX 35 add def /kinomeY kinomeY -4 add def\n";
    }elsif($name eq "MAPKAPK3"){
	return "/kinomeX kinomeX 52 add def\n";
    }elsif($name eq "MSK1~b"){
	return "/kinomeX kinomeX -2 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "MSK2~b"){
	return "/kinomeX kinomeX 30 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "RSK4~b"){
	return "/kinomeX kinomeX 35 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "RSK1~b"){
	return "/kinomeX kinomeX 35 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "RSK2~b"){
	return "/kinomeX kinomeX 37 add def\n";
    }elsif($name eq "TSSK2"){
	return "/kinomeX kinomeX 17 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "TSSK4"){
	return "/kinomeX kinomeX 12 add def\n";
    }elsif($name eq "Nek6"){
	return "/kinomeX kinomeX 9 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "Nek7"){
	return "/kinomeX kinomeX 17 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "Nek2"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "Nek8"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "Nek9"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 7 add def\n";
    }elsif($name eq "Nek11"){
	return "/kinomeX kinomeX 25 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "Nek4"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "Nek3"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "Nek1"){
	return "/kinomeX kinomeX 16 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "Nek5"){
	return "/kinomeX kinomeX 22 add def\n";
    }elsif($name eq "Nek10"){
	return "/kinomeX kinomeX 17 add def /kinomeY kinomeY -4 add def\n";
    }elsif($name eq "STK33"){
	return "/kinomeX kinomeX 15 add def\n";
    }elsif($name eq "MNK1"){
	return "/kinomeX kinomeX 24 add def\n";
    }elsif($name eq "MNK2"){
	return "/kinomeX kinomeX 6 add def\n";
    }elsif($name eq "PhK[gamma]1"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY -4 add def\n";
    }elsif($name eq "PhK[gamma]2"){
	return "/kinomeX kinomeX 6 add def\n";
    }elsif($name eq "PKD3"){
	return "/kinomeX kinomeX 24 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "DCAMKL1"){
	return "/kinomeX kinomeX 2 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "DCAMKL2"){
	return "/kinomeX kinomeX 2 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "CaMK4"){
	return "/kinomeX kinomeX 5 add def\n";
    }elsif($name eq "CaMK2[alpha]"){
	return "/kinomeX kinomeX 16 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "CaMK2[delta]"){
	return "/kinomeX kinomeX 2 add def /kinomeY kinomeY 10 add def\n";
    }elsif($name eq "CaMK2[beta]"){
	return "";
    }elsif($name eq "CaMK2[gamma]"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY -4 add def\n";
    }elsif($name eq "PKD1"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY -4 add def\n";
    }elsif($name eq "Trb1"){
	return "/kinomeX kinomeX 16 add def\n";
    }elsif($name eq "Trb2"){
	return "/kinomeX kinomeX 18 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "Trb3"){
	return "/kinomeX kinomeX 18 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "SgK495"){
	return "/kinomeX kinomeX 24 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "SgK085"){
	return "/kinomeX kinomeX 32 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "DRAK1"){
	return "/kinomeX kinomeX 27 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "DAPK1"){
	return "/kinomeX kinomeX 24 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "DAPK2"){
	return "/kinomeX kinomeX 10 add def\n";
    }elsif($name eq "caMLCK"){
	return "/kinomeX kinomeX 36 add def\n";
    }elsif($name eq "smMLCK"){
	return "/kinomeX kinomeX 34 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "skMLCK"){
	return "/kinomeX kinomeX 32 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "TTN"){
	return "/kinomeX kinomeX 14 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "DAPK3"){
	return "/kinomeX kinomeX 26 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "DRAK2"){
	return "/kinomeX kinomeX 29 add def /kinomeY kinomeY 1 add def\n";
    }elsif($name eq "Trad"){
	return "/kinomeX kinomeX 13 add def\n";
    }elsif($name eq "Trio"){
	return "/kinomeX kinomeX 13 add def\n";
    }elsif($name eq "Obscn"){
	return "/kinomeX kinomeX 28 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "SPEG"){
	return "/kinomeX kinomeX 20 add def\n";
    }elsif($name eq "Obscn~b"){
	return "/kinomeX kinomeX 36 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "SPEG~b"){
	return "/kinomeX kinomeX 32 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "Pim1"){
	return "/kinomeX kinomeX 18 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "Pim2"){
	return "/kinomeX kinomeX 8 add def /kinomeY kinomeY 8 add def\n";
    }elsif($name eq "Pim3"){
	return "/kinomeX kinomeX 6 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "CHK1"){
	return "/kinomeX kinomeX 22 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "PASK"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 7 add def\n";
    }elsif($name eq "Lkb1"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "SuRTK106"){
	return "/kinomeX kinomeX 18 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "JAK1~b"){
	return "/kinomeX kinomeX 33 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "Tyk2~b"){
	return "/kinomeX kinomeX 36 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "JAK2~b"){
	return "/kinomeX kinomeX 33 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "JAK3~b"){
	return "/kinomeX kinomeX 33 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "MOS"){
	return "/kinomeX kinomeX 12 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "Lmr1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "Lmr2"){
	return "/kinomeX kinomeX 2 add def /kinomeY kinomeY 8 add def\n";
    }elsif($name eq "Lmr3"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "EphA2"){
	return "/kinomeX kinomeX 13 add def /kinomeY kinomeY -2 add def\n";
    }elsif($name eq "Etk/BMX"){
	return "/kinomeX kinomeX 35 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "BTK"){
	return "/kinomeX kinomeX 12 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "ITK"){
	return "/kinomeX kinomeX 12 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "TEC"){
	return "/kinomeX kinomeX 12 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "TXK"){
	return "/kinomeX kinomeX 12 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "EphA8"){
	return "/kinomeX kinomeX 13 add def /kinomeY kinomeY -2 add def\n";
    }elsif($name eq "BLK"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "Fgr"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY -4 add def\n";
    }elsif($name eq "Lck"){
	return "/kinomeX kinomeX 8 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "Fyn"){
	return "/kinomeX kinomeX 6 add def /kinomeY kinomeY -4 add def\n";
    }elsif($name eq "HCK"){
	return "/kinomeX kinomeX 12 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "Lyn"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "Src"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "Yes"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "EphA7"){
	return "/kinomeX kinomeX 13 add def\n";
    }elsif($name eq "EphA4"){
	return "/kinomeX kinomeX 22 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "EphA6"){
	return "/kinomeX kinomeX 16 add def /kinomeY kinomeY -2 add def\n";
    }elsif($name eq "EphB4"){
	return "/kinomeX kinomeX 14 add def /kinomeY kinomeY -4 add def\n";
    }elsif($name eq "EphB3"){
	return "/kinomeX kinomeX 14 add def /kinomeY kinomeY -2 add def\n";
    }elsif($name eq "EphB1"){
	return "/kinomeX kinomeX 22 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "EphB2"){
	return "/kinomeX kinomeX 18 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "EphA3"){
	return "/kinomeX kinomeX 22 add def\n";
    }elsif($name eq "EphA5"){
	return "/kinomeX kinomeX 22 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "EphA10"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "EphB6"){
	return "/kinomeX kinomeX 14 add def\n";
    }elsif($name eq "EphA1"){
	return "/kinomeX kinomeX 18 add def\n";
    }elsif($name eq "Fer"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY -2 add def\n";
    }elsif($name eq "FRK"){
	return "/kinomeX kinomeX 12 add def\n";
    }elsif($name eq "Brk"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "Srm"){
	return "/kinomeX kinomeX 12 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "Abl"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "Arg"){
	return "/kinomeX kinomeX 12 add def\n";
    }elsif($name eq "CSK"){
	return "/kinomeX kinomeX 14 add def\n";
    }elsif($name eq "CTK"){
	return "/kinomeX kinomeX 12 add def\n";
    }elsif($name eq "FLT4"){
	return "/kinomeX kinomeX 12 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "CCK4/PTK7"){
	return "/kinomeX kinomeX 52 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "PDGFR[alpha]"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "PDGFR[beta]"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "Axl"){
	return "/kinomeX kinomeX 16 add def /kinomeY kinomeY 10 add def\n";
    }elsif($name eq "Mer"){
	return "/kinomeX kinomeX 14 add def /kinomeY kinomeY 8 add def\n";
    }elsif($name eq "FGFR1"){
	return "/kinomeX kinomeX 15 add def\n";
    }elsif($name eq "FGFR4"){
	return "/kinomeX kinomeX 16 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "FLT1"){
	return "/kinomeX kinomeX 2 add def\n";
    }elsif($name eq "KDR"){
	return "/kinomeX kinomeX 8 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "FmS/CSFR"){
	return "/kinomeX kinomeX 6 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "Kit"){
	return "/kinomeX kinomeX 6 add def /kinomeY kinomeY 8 add def\n";
    }elsif($name eq "IGF1R"){
	return "/kinomeX kinomeX 28 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "LTK"){
	return "/kinomeX kinomeX 14 add def /kinomeY kinomeY 1 add def\n";
    }elsif($name eq "ALK"){
	return "/kinomeX kinomeX 14 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "InSR"){
	return "/kinomeX kinomeX 16 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "DDR1"){
	return "/kinomeX kinomeX 22 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "DDR2"){
	return "/kinomeX kinomeX 22 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "MUSK"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "TRKA"){
	return "/kinomeX kinomeX 14 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "TRKB"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "TRKC"){
	return "/kinomeX kinomeX 18 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "FGFR2"){
	return "/kinomeX kinomeX 28 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "FGFR3"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "EGFR"){
	return "/kinomeX kinomeX 24 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "HER2"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "Tyro3/Sky"){
	return "/kinomeX kinomeX 12 add def /kinomeY kinomeY 8 add def\n";
    }elsif($name eq "Met"){
	return "/kinomeX kinomeX 13 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "Ron"){
	return "/kinomeX kinomeX 13 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "Ret"){
	return "/kinomeX kinomeX 6 add def\n";
    }elsif($name eq "FLT3"){
	return "/kinomeX kinomeX 16 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "Ros"){
	return "/kinomeX kinomeX 12 add def\n";
    }elsif($name eq "IRR"){
	return "/kinomeX kinomeX 4 add def\n";
    }elsif($name eq "ROR1"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "ROR2"){
	return "/kinomeX kinomeX 14 add def\n";
    }elsif($name eq "Tnk1"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "ZAP70"){
	return "/kinomeX kinomeX 14 add def\n";
    }elsif($name eq "HER3"){
	return "/kinomeX kinomeX 16 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "JAK3"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 10 add def\n";
    }elsif($name eq "PYK2"){
	return "/kinomeX kinomeX 18 add def\n";
    }elsif($name eq "TIE1"){
	return "/kinomeX kinomeX -2 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "RYK"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "HER4"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "Ack"){
	return "/kinomeX kinomeX 16 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "JAK1"){
	return "/kinomeX kinomeX 8 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "FAK"){
	return "/kinomeX kinomeX 14 add def /kinomeY kinomeY -2 add def\n";
    }elsif($name eq "JAK2"){
	return "/kinomeX kinomeX 0 add def /kinomeY kinomeY 6 add def\n";
    }elsif($name eq "Tyk2"){
	return "/kinomeX kinomeX 10 add def\n";
    }elsif($name eq "Fes"){
	return "/kinomeX kinomeX 12 add def\n";
    }elsif($name eq "Syk"){
	return "/kinomeX kinomeX 6 add def\n";
    }elsif($name eq "TIE2"){
	return "/kinomeX kinomeX 6 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "HPK1"){
	return "/kinomeX kinomeX 10 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "GCK"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "MST3"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "YSK1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "SgK223"){
	return "/kinomeX kinomeX 35 add def\n";
    }elsif($name eq "SgK269"){
	return "/kinomeX kinomeX 35 add def\n";
    }elsif($name eq "PINK1"){
	return "/kinomeX kinomeX 23 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "TTBK1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "TTBK2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "CaMK1[alpha]"){
	return "/kinomeX kinomeX 8 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "CaMK1[delta]"){
	return "/kinomeX kinomeX 32 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "HIPK4"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "SRPK2"){
	return "/kinomeX kinomeX 28 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "PRP4"){
	return "/kinomeX kinomeX 8 add def /kinomeY kinomeY 5 add def\n";
    }elsif($name eq "CLK1"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "CLK2"){
	return "/kinomeX kinomeX 22 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "CLK3"){
	return "/kinomeX kinomeX 22 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "CLK4"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "MSSK1"){
	return "/kinomeX kinomeX 30 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "SRPK1"){
	return "/kinomeX kinomeX 28 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "HIPK3"){
	return "/kinomeX kinomeX 18 add def /kinomeY kinomeY 2 add def\n";
    }elsif($name eq "DYRK4"){
	return "/kinomeX kinomeX 0 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "DYRK1A"){
	return "/kinomeX kinomeX 40 add def /kinomeY kinomeY 8 add def\n";
    }elsif($name eq "DYRK1B"){
	return "/kinomeX kinomeX 40 add def /kinomeY kinomeY 12 add def\n";
    }elsif($name eq "HIPK1"){
	return "/kinomeX kinomeX 27 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "HIPK2"){
	return "/kinomeX kinomeX 27 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "DYRK2"){
	return "/kinomeX kinomeX 20 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "DYRK3"){
	return "/kinomeX kinomeX 35 add def /kinomeY kinomeY 10 add def\n";
    }elsif($name eq "ADCK1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "ADCK2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "ADCK3"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "ADCK4"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "ADCK5"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "ChaK1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "ChaK2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "AlphaK1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "AlphaK2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "AlphaK3"){
	return "/kinomeX kinomeX 3 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "EEF2K"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "Brd2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "Brd3"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "Brd4"){
	return "/kinomeX kinomeX 7 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "BrdT"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "PDHK1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "PDHK2"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "PDHK3"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "PDHK4"){
	return "/kinomeX kinomeX 7 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "BCKDK"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "ATM"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "ATR"){
	return "/kinomeX kinomeX 4 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "mTOR/FRAP"){
	return "/kinomeX kinomeX 3 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "DNAPK"){
	return "/kinomeX kinomeX 3 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "SMG1"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "TRRAP"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "RIOK3"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "RIOK1"){
	return "/kinomeX kinomeX 3 add def /kinomeY kinomeY 4 add def\n";
    }elsif($name eq "RIOK2"){
	return "/kinomeX kinomeX 3 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "TIF[alpha]"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "TIF1[beta]"){
	return "/kinomeX kinomeX 5 add def /kinomeY kinomeY 3 add def\n";
    }elsif($name eq "TIF1[gamma]"){
	return "/kinomeX kinomeX 3 add def /kinomeY kinomeY 3 add def\n";
    }else{
	return "";
    }
}
# ==============================================================================
1;
