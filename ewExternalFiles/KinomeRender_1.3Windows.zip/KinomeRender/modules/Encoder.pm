# ==============================================================================
# Encoder.pm
# Jonathan Barker, 2005
# ==============================================================================
# Text handling module for the kinome rendering tool. This depends upon various
# PostScript definitions in prolog.ps...
# ==============================================================================

package Encoder;
use strict;
use warnings;

# ==============================================================================
# Package globals
# ==============================================================================
# $symbols                       Maps symbol names to encodings for Symbol font
# ==============================================================================

my $symbols =
{
    space => '\040',
    exclam => '\041',
    universal => '\042',
    numbersign => '\043',
    existential => '\044',
    percent => '\045',
    ampersand => '\046',
    suchthat => '\047',
    parenleft => '\050',
    parenright => '\051',
    asteriskmath => '\052',
    plus => '\053',
    comma => '\054',
    minus => '\055',
    period => '\056',
    slash => '\057',
    zero => '\060',
    one => '\061',
    two => '\062',
    three => '\063',
    four => '\064',
    five => '\065',
    six => '\066',
    seven => '\067',
    eight => '\070',
    nine => '\071',
    colon => '\072',
    semicolon => '\073',
    'less' => '\074',
    equal => '\075',
    greater => '\076',
    question => '\077',
    congruent => '\100',
    Alpha => '\101',
    Beta => '\102',
    Chi => '\103',
    Delta => '\104',
    Epsilon => '\105',
    Phi => '\106',
    Gamma => '\107',
    Eta => '\110',
    Iota => '\111',
    theta1 => '\112',
    Kappa => '\113',
    Lambda => '\114',
    Mu => '\115',
    Nu => '\116',
    Omicron => '\117',
    Pi => '\120',
    Theta => '\121',
    Rho => '\122',
    Sigma => '\123',
    Tau => '\124',
    Upsilon => '\125',
    sigma1 => '\126',
    Omega => '\127',
    Xi => '\130',
    Psi => '\131',
    Zeta => '\132',
    bracketleft => '\133',
    therefore => '\134',
    bracketright => '\135',
    perpendicular => '\136',
    underscore => '\137',
    radicalex => '\140',
    alpha => '\141',
    beta => '\142',
    chi => '\143',
    delta => '\144',
    epsilon => '\145',
    phi => '\146',
    gamma => '\147',
    eta => '\150',
    iota => '\151',
    phi1 => '\152',
    kappa => '\153',
    lambda => '\154',
    mu => '\155',
    nu => '\156',
    omicron => '\157',
    pi => '\160',
    theta => '\161',
    rho => '\162',
    sigma => '\163',
    tau => '\164',
    upsilon => '\165',
    omega1 => '\166',
    omega => '\167',
    xi => '\170',
    psi => '\171',
    zeta => '\172',
    braceleft => '\173',
    bar => '\174',
    braceright => '\175',
    similar => '\176',
    Euro => '\240',
    Upsilon1 => '\241',
    minute => '\242',
    lessequal => '\243',
    fraction => '\244',
    infinity => '\245',
    florin => '\246',
    club => '\247',
    diamond => '\250',
    heart => '\251',
    spade => '\252',
    arrowboth => '\253',
    arrowleft => '\254',
    arrowup => '\255',
    arrowright => '\256',
    arrowdown => '\257',
    degree => '\260',
    plusminus => '\261',
    second => '\262',
    greaterequal => '\263',
    multiply => '\264',
    proportional => '\265',
    partialdiff => '\266',
    bullet => '\267',
    divide => '\270',
    notequal => '\271',
    equivalence => '\272',
    approxequal => '\273',
    ellipsis => '\274',
    arrowvertex => '\275',
    arrowhorizex => '\276',
    carriagereturn => '\277',
    aleph => '\300',
    Ifraktur => '\301',
    Rfraktur => '\302',
    weierstrass => '\303',
    circlemultiply => '\304',
    circleplus => '\305',
    emptyset => '\306',
    intersection => '\307',
    union => '\310',
    propersuperset => '\311',
    reflexsuperset => '\312',
    notsubset => '\313',
    propersubset => '\314',
    reflexsubset => '\315',
    element => '\316',
    notelement => '\317',
    angle => '\320',
    gradient => '\321',
    registerserif => '\322',
    copyrightserif => '\323',
    trademarkserif => '\324',
    product => '\325',
    radical => '\326',
    dotmath => '\327',
    logicalnot => '\330',
    logicaland => '\331',
    logicalor => '\332',
    arrowdblboth => '\333',
    arrowdblleft => '\334',
    arrowdblup => '\335',
    arrowdblright => '\336',
    arrowdbldown => '\337',
    lozenge => '\340',
    angleleft => '\341',
    registersans => '\342',
    copyrightsans => '\343',
    trademarksans => '\344',
    summation => '\345',
    parenlefttp => '\346',
    parenleftex => '\347',
    parenleftbt => '\350',
    bracketlefttp => '\351',
    bracketleftex => '\352',
    bracketleftbt => '\353',
    bracelefttp => '\354',
    braceleftmid => '\355',
    braceleftbt => '\356',
    braceex => '\357',
    angleright => '\361',
    integral => '\362',
    integraltp => '\363',
    integralex => '\364',
    integralbt => '\365',
    parenrighttp => '\366',
    parenrightex => '\367',
    parenrightbt => '\370',
    bracketrighttp => '\371',
    bracketrightex => '\372',
    bracketrightbt => '\373',
    bracerighttp => '\374',
    bracerightmid => '\375',
    bracerightbt => '\376'
};


# ==============================================================================
# class Text
# ==============================================================================

sub _translate($)
{
    my $symbol=shift;

    # Translate a symbol using the table above.

    if(!defined($symbols->{$symbol}))
    {
        die "$symbol: unknown symbol\n";
    }

    return $symbols->{$symbol};
}

sub _encode($)
{
    my $s=shift;
    my @result;

    $s=~s/\(/\\(/g;
    $s=~s/\)/\\)/g;

    while(length($s))
    {

        if($s=~/^(.*?)\[([^\]]+)\](.*)$/)
        {
            my $pre=$1;
            my $symbol=$2;
            $s=$3;
            $symbol=_translate($symbol);
            push @result,"{kinomeNormal($pre)}" if length($pre);
            push @result,"{kinomeSymbol($symbol)}";
        }
        else
        {
            push @result,"{kinomeNormal($s)}";
            last;
        }
    }

    return "[".join('',@result)."]";
}

sub new($)
{
    my $class=shift;
    my $self=bless {},$class;

    # The syntax of text is plain ascii characters interspersed with symbols
    # in square brackets. For example "crap[alpha]1code".

    return $self;
}

sub encode($$)
{
    my $self=shift;
    my $text=shift;

    # Encode the text and return it as PostScript. See also
    # the PostScript procedures in prolog.ps

    return _encode($text);
}

# ==============================================================================

1;

